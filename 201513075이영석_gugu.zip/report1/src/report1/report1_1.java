package report1;

import java.util.Scanner;

public class report1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.print("������ �ϳ� �Է��ϼ���");
		int i = sc.nextInt();
		for(int j = 0; j < 10; j++) {
			System.out.println(i + " * " + j + " = " + i*j);
		}
		
	}

}
